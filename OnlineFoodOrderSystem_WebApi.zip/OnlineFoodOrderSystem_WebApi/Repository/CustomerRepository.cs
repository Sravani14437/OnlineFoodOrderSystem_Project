﻿using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderSystem_WebApi.DataLayer;
using OnlineFoodOrderSystem_WebApi.Models;
using OnlineFoodOrderSystem_WebApi.Repository;
namespace OnlineFoodOrderSystem_WebApi.Models
{

    public class CustomerRepository : ICustomerRepository

    {
        private readonly food_order_context _Context;
        public CustomerRepository(food_order_context context)
        {

            _Context = context ??
               throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Customer>> GetCustomer()
        {
            return await _Context.Customers.ToListAsync();
        }
        public async Task<Customer> GetCustomerByID(int Customerid)
        {
            return await _Context.Customers.FindAsync(Customerid);
        }
        public async Task<Customer> InsertCustomer(Customer customerobj)
        {
            _Context.Customers.Add(customerobj);
            await _Context.SaveChangesAsync();
            return customerobj;
        }
        public async Task<Customer> UpdateCustomer(Customer customerobj)
        {
            _Context.Entry(customerobj).State = EntityState.Modified;
            await _Context.SaveChangesAsync();
            return customerobj;
        }
        public bool DeleteCustomer(int Customerid)
        {
            bool result = false;
            var Customer = _Context.Customers.Find(Customerid);
            if (Customer != null)
            {
                _Context.Entry(Customer).State = EntityState.Deleted;
                _Context.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        
    }
}