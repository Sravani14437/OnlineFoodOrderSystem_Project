﻿using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderSystem_WebApi.DataLayer;
using OnlineFoodOrderSystem_WebApi.Models;

namespace OnlineFoodOrderSystem_WebApi.Repository
{
    public class PaymentTypeRepository:IPaymentTypeRepository 
    {
        private readonly food_order_context _Context;



        public PaymentTypeRepository(food_order_context context)
        {

            _Context = context ??
               throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<PaymentType>> GetOrder()
        {
            return await _Context.Paymenttype.ToListAsync();
        }
        public async Task<PaymentType> GetPaymentTypeByID(int PaymentTypeid)
        {
            return await _Context.Paymenttype.FindAsync(PaymentTypeid);
        }
        public async Task<PaymentType> InserPaymentType(PaymentType paymenttypeobj)
        {
            _Context.Paymenttype.Add(paymenttypeobj);
            await _Context.SaveChangesAsync();
            return paymenttypeobj;
        }
        public async Task<PaymentType> UpdatePaymentType(PaymentType paymentypeobj)
        {
            _Context.Entry(paymentypeobj).State = EntityState.Modified;
            await _Context.SaveChangesAsync();
            return paymentypeobj;
        }
        public bool DeletePaymentType(int PaymentTypeid)
        {
            bool result = false;
            var PaymentType = _Context.Paymenttype.Find(PaymentTypeid);
            if (PaymentType != null)
            {
                _Context.Entry(PaymentType).State = EntityState.Deleted;
                _Context.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public bool DeletePaymentType()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<PaymentType>> GetPaymentType()
        {
            throw new NotImplementedException();
        }

        

        public Task<PaymentType> InsertPaymentType(PaymentType paymenttypeobj)
        {
            throw new NotImplementedException();
        }

        
    }
}
