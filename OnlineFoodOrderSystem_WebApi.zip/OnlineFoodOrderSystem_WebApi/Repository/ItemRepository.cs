﻿using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderSystem_WebApi.DataLayer;
using OnlineFoodOrderSystem_WebApi.Models;
using OnlineFoodOrderSystem_WebApi.Repository;
namespace OnlineFoodOrderSystem_WebApi.Models
{

    public class ItemRepository : IItemRepository

    {
        private readonly food_order_context _Context;
        public ItemRepository(food_order_context context)
        {

            _Context = context ??
               throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Item>> GetItem()
        {
            return await _Context.Items.ToListAsync();
        }
        public async Task<Item> GetItemByID(int Itemid)
        {
            return await _Context.Items.FindAsync(Itemid);
        }
        public async Task<Item> InsertItem(Item itemobj)
        {
            _Context.Items.Add(itemobj);
            await _Context.SaveChangesAsync();
            return itemobj;
        }
        public async Task<Item> UpdateItem(Item itemobj)
        {
            _Context.Entry(itemobj).State = EntityState.Modified;
            await _Context.SaveChangesAsync();
            return itemobj;
        }
        public bool DeleteItem(int Itemid)
        {
            bool result = false;
            var Items = _Context.Items.Find(Itemid);
            if (Items != null)
            {
                _Context.Entry(Items).State = EntityState.Deleted;
                _Context.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public Task<Item> GetCustomerByID(int Itemid)
        {
            throw new NotImplementedException();
        }
    }
}