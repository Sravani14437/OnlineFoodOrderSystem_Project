﻿using OnlineFoodOrderSystem_WebApi.Models;

namespace OnlineFoodOrderSystem_WebApi.Repository
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetOrder();
        Task<Order> GetOrderByID(int Orderid);
        Task<Order> InsertOrder(Order orderobj);
        Task<Order> UpdateOrder(Order orderobj);
        bool DeleteOrder(int Orderid);
    }
}
