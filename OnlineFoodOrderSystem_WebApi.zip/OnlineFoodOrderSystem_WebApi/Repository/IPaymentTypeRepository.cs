﻿using OnlineFoodOrderSystem_WebApi.Models;

namespace OnlineFoodOrderSystem_WebApi.Repository
{
    public interface IPaymentTypeRepository
    {
        Task<IEnumerable<PaymentType>> GetPaymentType();
        Task<PaymentType> GetPaymentTypeByID(int PaymentTypeid);
        Task<PaymentType> InsertPaymentType(PaymentType paymenttypeobj);
        Task<PaymentType> UpdatePaymentType(PaymentType paymenttypeobj);
        bool DeletePaymentType(int PaymentTypeid);
    }
}
