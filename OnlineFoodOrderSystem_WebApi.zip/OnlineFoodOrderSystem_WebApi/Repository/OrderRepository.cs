﻿using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderSystem_WebApi.DataLayer;
using OnlineFoodOrderSystem_WebApi.Models;
using OnlineFoodOrderSystem_WebApi.Repository;

public class OrderRepository : IOrderRepository

{
    private readonly food_order_context _Context;

    

    public OrderRepository(food_order_context context)
    {

        _Context = context ??
           throw new ArgumentNullException(nameof(context));
    }
    public async Task<IEnumerable<Order>> GetOrder()
    {
        return await _Context.Orders.ToListAsync();
    }
    public async Task<Order> GetOrderByID(int orderid)
    {
        return await _Context.Orders.FindAsync(orderid);
    }
    public async Task<Order> InsertOrder(Order orderobj)
    {
        _Context.Orders.Add(orderobj);
        await _Context.SaveChangesAsync();
        return orderobj;
    }
    public async Task<Order> UpdateOrder(Order orderobj)
    {
        _Context.Entry(orderobj).State = EntityState.Modified;
        await _Context.SaveChangesAsync();
        return orderobj;
    }
    public bool DeleteOrder(int Orderid)
    {
        bool result = false;
        var Orders = _Context.Orders.Find(Orderid);
        if (Orders != null)
        {
            _Context.Entry(Orders).State = EntityState.Deleted;
            _Context.SaveChanges();
            result = true;
        }
        else
        {
            result = false;
        }
        return result;
    }

    public bool DeleteOrder( )
    {
        throw new NotImplementedException();
    }
}