﻿using OnlineFoodOrderSystem_WebApi.Models;

namespace OnlineFoodOrderSystem_WebApi.Repository
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetCustomer();
        Task<Customer> GetCustomerByID(int Customerid);
        Task<Customer> InsertCustomer(Customer customerobj);
        Task<Customer> UpdateCustomer(Customer customerobj);
        bool DeleteCustomer(int Customerid);
    }
}
