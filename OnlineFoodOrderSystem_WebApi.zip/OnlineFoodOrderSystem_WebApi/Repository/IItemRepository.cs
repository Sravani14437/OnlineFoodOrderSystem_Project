﻿using OnlineFoodOrderSystem_WebApi.Models;

namespace OnlineFoodOrderSystem_WebApi.Repository
{
    public interface IItemRepository
    {

        Task<IEnumerable<Item>> GetItem();
        Task<Item> GetItemByID(int Itemid);
        Task<Item> InsertItem(Item itemobj);
        Task<Item> UpdateItem(Item itemobj);
        bool DeleteItem(int Itemid);

    }
}
