﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderSystem_WebApi.Repository;

namespace OnlineFoodOrderSystem_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentTypeController : ControllerBase
    {
        private readonly IPaymentTypeRepository _Context;
        public PaymentTypeController(IPaymentTypeRepository context)
        {


            _Context = context ??
                throw new ArgumentNullException(nameof(context));
        }
        [HttpGet]
        [Route("GetPaymentType")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Context.GetPaymentType());
        }
        [HttpGet]
        [Route("GetPaymentTypeByID/{Id}")]
        public async Task<IActionResult> GetPaymentTypeByid(int PaymentTypeid)
        {
            return Ok(await _Context.GetPaymentTypeByID(PaymentTypeid));
        }
    }
}

