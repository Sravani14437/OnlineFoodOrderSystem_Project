﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderSystem_WebApi.Repository;

namespace OnlineFoodOrderSystem_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository MyContext;
        public CustomerController(ICustomerRepository context)
        {
            MyContext = context??
                throw new ArgumentNullException(nameof(context));
        }
        [HttpGet]
        [Route("GetCustomer")]
        public async Task<IActionResult> Get()
        {
            return Ok(await MyContext.GetCustomer());
        }
        [HttpGet]
        [Route("GetCustomerByID/{Id}")]
        public async Task<IActionResult> GetCustomerByid(int Customerid)
        {
            return Ok(await MyContext.GetCustomerByID(Customerid));
        }
    }
}
