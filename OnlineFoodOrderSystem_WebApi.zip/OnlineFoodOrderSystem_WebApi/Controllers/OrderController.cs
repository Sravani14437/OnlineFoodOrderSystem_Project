﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderSystem_WebApi.Repository;

namespace OnlineFoodOrderSystem_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _Context;
        public OrderController(IOrderRepository context)
        {
            
            
            _Context = context ??
                throw new ArgumentNullException(nameof(context));
        }
        [HttpGet]
        [Route("GetOrder")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Context.GetOrder());
        }
        [HttpGet]
        [Route("GetOrderByID/{Id}")]
        public async Task<IActionResult> GetCustomerByid(int Orderid)
        {
            return Ok(await _Context.GetOrderByID(Orderid));
        }
    }
}
    

