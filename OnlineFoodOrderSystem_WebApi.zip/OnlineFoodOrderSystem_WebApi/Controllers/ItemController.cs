﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineFoodOrderSystem_WebApi.Repository;

namespace OnlineFoodOrderSystem_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _Context;
        public ItemController(IItemRepository context)
        {


            _Context = context ??
                throw new ArgumentNullException(nameof(context));
        }
        [HttpGet]
        [Route("GetItem")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Context.GetItem());
        }
        [HttpGet]
        [Route("GetItemByID/{Id}")]
        public async Task<IActionResult> GetItemByid(int Itemid)
        {
            return Ok(await _Context.GetItemByID(Itemid));
        }
    }
}

