﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFoodOrderSystem_WebApi.Models
{
    [Table("Order")]
    public class PaymentType
    {
        [Key]
        public int PaymentTypeid { get; set; }
        public string PaymentTypename { get; set; }
    }
        
}
