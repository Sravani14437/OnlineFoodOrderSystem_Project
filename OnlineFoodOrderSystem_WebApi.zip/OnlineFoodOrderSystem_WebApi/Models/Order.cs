﻿using OnlineFoodOrderSystem_WebApi.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFoodOrderSystem_WebApi.Models
{
    [Table("Order")]
    public class Order
    {
        [Key]
        public int Orderid { get; set; }
        public int PaymentTypeid { get; set; }
        public int Customerid { get; set; }
        public int Ordernumber { get; set; }
        public int Orderdate { get; set; }

    }
}
