﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFoodOrderSystem_WebApi.Models
{
    [Table("Customer")]
    public class Customer
    {
        [Key]
        public int Customerid { get; set; }
        public string? Customername { get; set; }
    }
}
