﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace OnlineFoodOrderSystem_WebApi.Models
{
    [Table("Item")]

    public class Item
    {
        
        
        
            [Key]
            public int Itemid { get; set; }
             public int Itemprice { get; set; }

            public string? Itemname { get; set; }


    }
}

