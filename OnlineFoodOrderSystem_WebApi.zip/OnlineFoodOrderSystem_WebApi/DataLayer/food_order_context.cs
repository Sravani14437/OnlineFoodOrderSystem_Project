﻿using Microsoft.EntityFrameworkCore;
using OnlineFoodOrderSystem_WebApi.Models;
using OnlineFoodOrderSystem_WebApi.DataLayer;

namespace OnlineFoodOrderSystem_WebApi.DataLayer
{
    public class food_order_context : DbContext
    {
        public food_order_context(DbContextOptions<food_order_context> options) : base(options)
        {
        }

       
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<PaymentType> Paymenttype { get; set; }
        
    }
}
