﻿using Microsoft.AspNetCore.Mvc;
using MVC_OnlineFoodOrderSystem.Models;
using System.Diagnostics;

namespace MVC_OnlineFoodOrderSystem.Controllers
{
    public class HomeController : Controller
    {


    }
}