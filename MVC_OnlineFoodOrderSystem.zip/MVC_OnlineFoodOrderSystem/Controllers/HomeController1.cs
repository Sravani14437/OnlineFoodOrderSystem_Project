﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MVC_OnlineFoodOrderSystem.Models;

namespace MVC_OnlineFoodOrderSystem.Controllers
{
    public class HomeController1 : Controller
    {
        public object FormsAuthentication { get; private set; }

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        // GET: UserDetail
        //Login Authentication
        //Only able access this Actionmethod when User Log in
        [Authorize]
        public ActionResult UserDetail()
        {
            return View();
        }
         
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel LoginViewModel)
        {
            if (IsAuthenitcatedUser(LoginViewModel.Email, LoginViewModel.Password))
            {
                
                FormsAuthentication.SetAuthCookie(LoginViewModel.Email, false);
                return RedirectToAction("UserDetail", "Home");
            }
            else
            {
                ModelState.AddModelError("", "Your credentail is incorrect");
            }
            return View(LoginViewModel);
        }
        // GET:Register return view
        [HttpGet]
        public ActionResult UserRegistration()
        {
            return View();
        }
        // Post:Register 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserRegistration(RegistrationViewModel RegistrationViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsEmailExist(RegistrationViewModel.Email))
                    {
                        LoginRegistrationMVC db = new LoginRegistrationMVC();
                        {
                            RegistrationUser userobj = new RegistrationUser
                            {
                                Email = RegistrationViewModel.Email,
                                Name = RegistrationViewModel.Name,
                                
                                Encryptedpassword = Base64Encode(RegistrationViewModel.Password),
                                Address = RegistrationViewModel.Address
                            };
                            userobj = db.RegistrationUsers.Add(userobj);
                            if (db.SaveChanges() > 0)
                            {
                                
                                FormsAuthentication.SetAuthCookie(RegistrationViewModel.Email, false);
                                return RedirectToAction("UserDetail", "Home");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Something went wrong please try again later!");
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "email already exist please try with diffrent one!");
                    }

                }
                else
                {
                    ModelState.AddModelError("", "Model is Invalid");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("", e.Message);
            }
            return View();
        }
        

        private bool IsEmailExist(string Email)
        {
            bool IsEmailExist = false;
            LoginRegistrationMVC db = new LoginRegistrationMVC();
            {
                int count = db.RegistrationUsers.Where(a => a.Email==Email).Count();
                if (count > 0)
                {
                    IsEmailExist = true;
                }
            }
            return IsEmailExist;
        }
        private bool IsAuthenitcatedUser(string email, string password)
        {
            var encryptpassowrd = Base64Encode(password);
            bool IsValid = false;
            LoginRegistrationMVC db = new LoginRegistrationMVC();
            {
                int count = db.RegistrationUsers.Where(a => a.Email == email).Count();
                if (count > 0)
                {
                    IsValid = true;
                }
            }
            return IsValid;
        }
        private static string Base64Encode(string PlainPassword)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(PlainPassword);
            return System.Convert.ToBase64String(plainTextBytes);
        }

    }

    internal class LoginRegistrationMVC
    {
    }
}
 


    

